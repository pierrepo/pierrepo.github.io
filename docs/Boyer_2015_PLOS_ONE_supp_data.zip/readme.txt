
S1_Protocol.pdf
10.1371/journal.pone.0116414.s001

S2_Protocol.pdf
10.1371/journal.pone.0116414.s002

S3_Protocol.pdf
10.1371/journal.pone.0116414.s003

S1_Dataset.pdf
10.1371/journal.pone.0116414.s004

S2_Dataset.pdf
10.1371/journal.pone.0116414.s005

S1_Fig.eps
<div><p>After energy filtering, binding geometries issued from ATTRACT docking simulations are characterized by Heligeom in terms of the number of monomers per turn (N) and pitch value (P) of associated regular assemblies, and are separated into “Filament” (blue), “Cyclic” (green), “Near-cyclic” (orange) or “Near-helical” (red) categories based on their corresponding position in the plot of <i>P</i> versus <i>N</i> schematized here. In the present work, the horizontal dotted line separating the &#8220;Filament&#8221; from the other categories has been set at <i>P</i> = 2<i>R</i><sub><i>M</i></sub>, where <i>R</i><sub><i>M</i></sub> is the maximum radius of the monomer. The green boxed areas correspond to “Cyclic” geometries centered on integral values of <i>N</i> &#177; 0.1 with allowed values of <i>P</i> &#8804; 0.5 &#197;. &#8220;Near-cyclic&#8221; geometries are defined by accepting a pitch error of up to 5 &#197; per interface, and thus <i>P </i> N &#8722; 1) &#215; 5 &#197;. These geometries are shunted to an automated Monte Carlo energy-minimization (adjustment) procedure in which cyclic geometry is enforced.</p>
</div>
10.1371/journal.pone.0116414.s006

S2_Fig.eps
<div><p>The screw axis is defined by point O and direction Δ. The transformation from monomer A to monomer B is the combination of a rotation <i>&#952;</i> around the axis and a translation <i>trans</i> along the axis.</p>
</div>
10.1371/journal.pone.0116414.s007

S3_Fig.eps
<div><p>(Top) residues on the 2REB<sub>core</sub> surface have been colored according to the sequence conservation index (CI) of 63 RecA proteins (Karlin and Brocchieri, J Bacteriology 1996, 178, 1881&#8211;1894); selected values are reported in Table S1&#8211;1 of <a href="http://www.plosone.org/article/info:doi/10.1371/journal.pone.0116414#pone.0116414.s004" target="_blank">S1 Dataset</a>, supporting information; (bottom) the residues have been colored according to the docking results; reproduced from <a href="http://www.plosone.org/article/info:doi/10.1371/journal.pone.0116414#pone.0116414.g002" target="_blank">Fig. 2D</a>, main manuscript.</p>
</div>
10.1371/journal.pone.0116414.s008

S4_Fig.eps
<div><p>Each circle on the P versus N plot, in which P is the pitch (Å) and N the number of monomers per turn, represents one docking pose geometry after filtering and post-processing as described in Methods and <a href="http://www.plosone.org/article/info:doi/10.1371/journal.pone.0116414#pone.0116414.g001" target="_blank">Fig. 1</a> (main article), <a href="http://www.plosone.org/article/info:doi/10.1371/journal.pone.0116414#pone.0116414.s001" target="_blank">S1 Protocol</a> and <a href="http://www.plosone.org/article/info:doi/10.1371/journal.pone.0116414#pone.0116414.s006" target="_blank">S1 Fig</a> (supporting information). Pitch values for left-handed helical geometries (parameter <i>dir</i> in Methods) are given as negative values. Points are colored by the interface energy of the corresponding association geometry, with darker values indicating more favorable energies.</p>
</div>
10.1371/journal.pone.0116414.s009

S5_Fig.eps
<div><p>The fiber forms A to I (<a href="http://www.plosone.org/article/info:doi/10.1371/journal.pone.0116414#pone.0116414.g003" target="_blank">Fig. 3</a>, main manuscript and SI <a href="http://www.plosone.org/article/info:doi/10.1371/journal.pone.0116414#pone.0116414.s002" target="_blank">S2 Protocol</a>) are displayed in ribbon representation, with monomers alternatively colored in white or gray. The extremities of the flexible regions are shown in van der Waals representation, with the extremities of loop L1 (residues 156 and 165) in blue, those of loop L2 (194, 210) in red and the linker extremity (residue 38) in green. The N-terminal helix binding region (residues 89, 124, 127&#8211;128, 131&#8211;132, 135&#8211;138) is in orange.</p>
</div>
10.1371/journal.pone.0116414.s010

S6_Fig.eps
<div><p>Comparison between the cyclic octameric form of Dmc1 (1V5W in green, Kinebuchi et al., Mol Cell 14, 363–374, 2003), and a helical form obtained using ATTRACT/Heligeom (violet) following the same procedure that was used for RecA. The construction and the present representation were restricted to the monomer rigid core (residues 99–270, 290–340) of 1V5W. Cartoon representations show the “receptor” and “ligand” monomers, both in yellow for the cyclic octamer and in yellow and violet respectively for the helical form. The two forms are superimposed using the receptor monomer. The two assembly modes share 61% of monomer-monomer contact pairs. Their interaction energies are within 1 RT, and C<sub><i>&#945;</i></sub>-RMSD calculated for their ligand monomers is 5.5 Å. The number of monomers per turn N = 7.4 and pitch P = 79.0 Å characterizing the right-handed helical form are compatible with geometries seen in filaments active in homologous recombination.</p>
</div>
10.1371/journal.pone.0116414.s011

S7_Fig.eps
<div><p>(A) Comparison of X (left) and X* (right) modes of monomer-monomer association. Two consecutive monomers issued from the PDB files 2REB (left) and 3CMW (right) are represented. In both cases, the top monomer is represented in surface mode, in white. The bottom monomer is shown in a ribbon representation and with an orientation that is common to both panels left and right. The rigid core is in grey; the L1 loop (right) or its extremities (left) are in blue; the L2 loop (right) or its extremities (left) are in red; the N-terminal domain, including a terminal helix and a flexible linker, are in green (right) or green and orange (left), the orange region corresponding to the fraction of the linker which folds back on its own monomer in structure 2REB (residues 30–37). The ATP cofactor in the right panel is in purple. (B) Results from targeted docking simulations on X (left) and X* (right) modes of association, characterized by their pitch P and number of monomers per turn N; the results were obtained in the presence (red +) or in the absence (blue ×) of flexible or mobile elements, the 30–37 linker segment for X (left) and the ATP cofactor for X* (right) (see <a href="http://www.plosone.org/article/info:doi/10.1371/journal.pone.0116414#pone.0116414.s005" target="_blank">S2 Dataset</a>).</p>
</div>
10.1371/journal.pone.0116414.s012

S8_Fig.eps
<div><p>(A) Construction of a set of reference points used to measure the groove width of a protein filament. <i>r</i> and <i>R</i> are respectively the inner and outer radii of the filament, reference points are taken every 1 &#197; between (<i>r</i> + <i>R</i>)/2 and <i>R</i>. (B) Visual representation of the reference points (in red) used to compute the groove width of a RecA filament. Values are calculated every half degree. Further details are provided in <a href="http://www.plosone.org/article/info:doi/10.1371/journal.pone.0116414#pone.0116414.s003" target="_blank">S3 Protocol</a>, supporting information.</p>
</div>
10.1371/journal.pone.0116414.s013

S9_Fig.eps
<div><p>Groove width variations along one filament turn (360<sup>&#8728;</sup>) are represented for the X filament form (black line), the X* filament form (red line) and the model with alternate X and X* interfaces (green line) (see <a href="http://www.plosone.org/article/info:doi/10.1371/journal.pone.0116414#pone.0116414.s003" target="_blank">S3 Protocol</a> and <a href="http://www.plosone.org/article/info:doi/10.1371/journal.pone.0116414#pone.0116414.s013" target="_blank">S8 Fig</a>, supporting information).</p>
</div>
10.1371/journal.pone.0116414.s014
